const express = require('express');
const app = express(); 
const cors = require('cors');
const auth = require('./API/Utils/jwtVerification');
const httpContext = require('express-http-context');
const Admin = require('./API/Routes/admin');
const CreateUser = require('./API/Routes/user_data');
const AuthenticatedUser = require('./API/Routes/authenticated_user');
const wallet = require('./API/Routes/user_wallet_data');
const PaymentRequest = require('./API/Routes/payment_request');
const AdminRequirement = require('./API/Routes/admin_requirement');

app.use(cors()); 
const mongoose = require('mongoose')
// mongodb://0.0.0.0:27017/Arena_FX
// mongodb://ArenaUser:Arena_FX_Vip@13.201.44.16:27017/Arena_FX
mongoose.connect("mongodb://ArenaUser:Arena_FX_Vip@13.201.44.16:27017/Arena_FX", {
    useNewUrlParser: true, 
    useUnifiedTopology: true 
}, (err) => {
    if (err) { 
        console.log(err)
    } else {
        console.log("DB Connection Success!!")
    }
}) 

app.use(express.json({ extended: false, limit: '50mb' }))
app.use(express.urlencoded({ limit: '50mb', extended: false, parameterLimit: 50000 }))
app.use(httpContext.middleware);
app.use('/api/Admin', Admin);
app.use('/api/user', CreateUser);
app.use('/Auth/API',auth, AuthenticatedUser); 
app.use('/Auth/wallet',auth, wallet); 
app.use('/Auth/Pay',auth, PaymentRequest);
app.use('/Auth/Admin', AdminRequirement);

app.use((req, res, next) => {
    res.status(404).json({
        message: 'Invalid response',
        status_code: '404'
    })
})

module.exports = app;
 
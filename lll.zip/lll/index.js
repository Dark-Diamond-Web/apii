// const http = require('http');
// const app = require('./app')
// const server = http.createServer(app);

// server.listen(80, console.log('Server Started on 80'));

const https = require("https");
const hostname = 'https://client.facesense.co/';        
const express = require("express"); 
const app = require('./app');
const fs = require("fs");
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const options = {
    key: fs.readFileSync("/etc/letsencrypt/live/www.arenafx.vip/privkey.pem"),                  
    cert: fs.readFileSync("/etc/letsencrypt/live/www.arenafx.vip/cert.pem"),             
    ca: fs.readFileSync('/etc/letsencrypt/live/www.arenafx.vip/fullchain.pem'),             
};

https.createServer(options, app)
    .listen(2100, function (req, res) {                        
        console.log("Office Use Server Started on 2100");           
    });
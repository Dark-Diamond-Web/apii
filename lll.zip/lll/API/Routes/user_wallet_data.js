const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const wallet_model = require('../Model/user_wallet_data')
const httpContext = require('express-http-context');

router.post('/register', (req, res, next) => {
    const AuthKey = httpContext.get("AuthKey");
    const Wallet_model = new wallet_model({
        _id: new mongoose.Types.ObjectId,
        wallet_name: req.body.wallet_name,
        Wallet_Address: req.body.Wallet_Address,
        QR_ScrShot: req.body.QR_ScrShot,
        AuthKey: AuthKey
    })
    Wallet_model.save()
        .then(result => {
            res.status(200).json({
                Message: result
            })
        })
        .catch(err => { 
            res.status(500).json({
                error: err
            })
        })
});

router.get('/WalletData', (req, res, next) => {
    const AuthKey = httpContext.get("AuthKey");
    wallet_model.find({ AuthKey: AuthKey })
        .select("-__v")
        .exec()
        .then(result => {
            res.status(200).json({
                wallet_model: result,
                Status_Code: 200
            });
        })
        .catch(err => { 
            res.status(500).json({
                error: err
            })
        })
})

module.exports = router; 
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const User_data_model = require('../Model/user_data_model')
const Email_OTP_Verification = require('../Model/Email_OTP_verification');
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt')



var transporter = nodemailer.createTransport({
    host: "smtpout.secureserver.net",
    port: 587,
    // secure: true,
    auth: {
        user: "info@arenafx.vip",
        pass: "Arenafx@24",
    },
    tls: {
        rejectUnauthorized: false,
    },
});

router.post('/GenerateOTP', (req, res, next) => {
    User_data_model.find({ Email_ID: req.body.Email_ID.toLowerCase() })
        .select("-__v")
        .exec()
        .then(result => {
            if (result.length !== 0) {
                res.status(200).json({
                    message: "Email ID already registered",
                    Status_Code: 300
                });
            } else {
                Email_OTP_Verification.find({ Email_ID: req.body.Email_ID.toLowerCase() })
                    .exec()
                    .then(result => {
                        if (result.length !== 0) {
                            Email_OTP_Verification.deleteMany({ Email_ID: req.body.Email_ID.toLowerCase() })
                                .then(() => {
                                    const Email_ID = req.body.Email_ID.toLowerCase();
                                    const Name = req.body.First_Name;
                                    SendOTPVerificationEmail(Email_ID, Name)
                                        .then(() => {
                                            res.status(200).json({
                                                message: "OTP has been sent successfully!!",
                                                Status_Code: 200
                                            });
                                        })
                                        .catch(err => {
                                            res.status(500).json({
                                                error: err.message
                                            });
                                        });
                                });
                        } else {
                            const Email_ID = req.body.Email_ID.toLowerCase();
                            const Name = req.body.First_Name;
                            SendOTPVerificationEmail(Email_ID, Name)
                                .then(() => {
                                    res.status(200).json({
                                        message: "OTP has been sent successfully!!",
                                        Status_Code: 200
                                    });
                                })
                                .catch(err => {
                                    res.status(500).json({
                                        error: err.message
                                    });
                                });
                        }
                    });
            }
        })
        .catch(err => {
            res.status(500).json({
                error: err.message
            });
        });
});

const SendOTPVerificationEmail = async (Email_ID, Name) => {
    try {
        const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
        const mailOptions = {
            from: '"Arena FX" <info@arenafx.vip>',
            to: Email_ID,
            subject: 'Your One-Time Password (OTP) for Arena FX',
            html: `
            <p>Dear <strong>${Name} !</strong> </p> 
            <p>For your security, we have generated a One-Time Password (OTP) to complete your recent action on Arena FX. Please use the OTP below to proceed:</p>
            <p>Your OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
            <p>This OTP is valid for the next 2 minutes. If you did not request this OTP, please contact our support team immediately.</p><br>
            <p>To ensure the security of your account, do not share this OTP with anyone. Arena FX will never ask you for your password or OTP.</p>
            <p>If you have any questions or need further assistance, feel free to contact us at support@arenaFX.com.</p><br>
            <p>Thank you for choosing Arena FX.</p><br>
            <p>Best regards,</p>
            <p>Customer Support Team </p>
            <p>Arena FX VIP</p>
            `
        };
        const saltRounds = 2;
        const hashedOTP = await bcrypt.hash(otp, saltRounds);
        const email_OTP_Verification = new Email_OTP_Verification({
            _id: new mongoose.Types.ObjectId(),
            Email_ID: Email_ID,
            otp: hashedOTP,
            CreatedTime: Date.now(),
            ExpiredTime: Date.now() + 120000,
        });
        await email_OTP_Verification.save();
        await transporter.sendMail(mailOptions);
    } catch (error) {
        throw new Error(error.message);
    }
};

// var transporter = nodemailer.createTransport({
//     host: "smtpout.secureserver.net",
//     port: 587,
//     // secure: true,
//     auth: {
//         user: "info@arenafx.vip",
//         pass: "Arenafx@24",
//     },
//     tls: {
//         rejectUnauthorized: false,
//     },
// })

// router.post('/GenerateOTP', (req, res, next) => {
//     User_data_model.find({ Email_ID: req.body.Email_ID.toLowerCase() })
//         .select("-__v")
//         .exec()
//         .then(result => {
//             if (result.length !== 0) {
//                 res.status(200).json({
//                     message: "Email ID already registred",
//                     Status_Code: 300
//                 });
//             }
//             if (result.length == 0) {
//                 Email_OTP_Verification.find({ Email_ID: req.body.Email_ID.toLowerCase() })
//                     .exec()
//                     .then(result => {
//                         if (result.length !== 0) {
//                             Email_OTP_Verification.remove({ Email_ID: req.body.Email_ID.toLowerCase() })
//                                 .then(result => {
//                                     const Email_ID = req.body.Email_ID.toLowerCase();
//                                     const Name = req.body.First_Name;
//                                     SendOTPVerificationEmail(Email_ID, Name)
//                                     res.status(200).json({
//                                         message: "OTP has been sent successfully!!",
//                                         Status_Code: 200
//                                     });
//                                 })
//                         }
//                         if (result.length == 0) {
//                             const Email_ID = req.body.Email_ID.toLowerCase();
//                             const Name = req.body.First_Name;
//                             SendOTPVerificationEmail(Email_ID, Name)
//                             res.status(200).json({
//                                 message: "OTP has been sent successfully!!",
//                                 Status_Code: 200
//                             });
//                         }
//                     })
//             }
//         })
//         .catch(err => {
//             // console.log(err);
//             res.status(500).json({
//                 error: err
//             })
//         })
// })

// const SendOTPVerificationEmail = async (Email_ID, Name, res) => {
//     try {
//         const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
//         const mailOptions = {
//             from: '"Arena FX" <info@arenafx.vip>',
//             to: Email_ID,
//             subject: 'Your One-Time Password (OTP) for Arena FX',
//             html: `
//             <p>Dear <strong>${Name} !</strong> </p> 
//             <p>For your security, we have generated a One-Time Password (OTP) to complete your recent action on Arena FX. Please use the OTP below to proceed:</p>
//             <p>Your OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
//             <p>This OTP is valid for the next 2 minutes. If you did not request this OTP, please contact our support team immediately.</p><br>
//             <p>To ensure the security of your account, do not share this OTP with anyone. Arena FX will never ask you for your password or OTP.</p>
//             <p>If you have any questions or need further assistance, feel free to contact us at support@arenaFX.com.</p><br>
//             <p>Thank you for choosing Arena FX.</p><br>
//             <p>Best regards,</p>
//             <p>Customer Support Team </p>
//             <p>Arena FX VIP</p>
//             `
//         };
//         const saltRounds = 2;
//         const hashedOTP = await bcrypt.hash(otp, saltRounds);
//         const email_OTP_Verification = await Email_OTP_Verification({
//             _id: new mongoose.Types.ObjectId,
//             Email_ID: Email_ID,
//             otp: hashedOTP,
//             CreatedTime: Date.now(),
//             ExpiredTime: Date.now() + 120000,
//         });
//         await email_OTP_Verification.save();
//         await transporter.sendMail(mailOptions);
//     }
//     catch (error) {
//         res.json({
//             status: "Failed",
//             message: error.message,
//         });
//     }
// }

router.post("/Verify_OTP", async (req, res) => {
    try {
        const Email_ID = req.body.Email_ID.toLowerCase();
        const otp = req.body.otp;
        if (!Email_ID || !otp) {
            throw Error("Empty OTP Details are not Allowed!")
        } else {
            const email_OTP_Verification = await Email_OTP_Verification.find({
                Email_ID,
            });
            if (email_OTP_Verification.length <= 0) {
                throw new Error(
                    "OTP has been verified already!"
                );
            } else {
                const { ExpiredTime } = email_OTP_Verification[0];
                const hashedOTP = email_OTP_Verification[0].otp;
                if (ExpiredTime < Date.now()) {
                    await Email_OTP_Verification.deleteMany({ Email_ID });
                    throw new Error("OTP Expired. Please request again");
                } else {
                    const validOTP = await bcrypt.compare(otp, hashedOTP);
                    if (!validOTP) {
                        throw new Error("Invalid Code Passed. Check Again");
                    } else {
                        await Email_OTP_Verification.updateOne({ Email_ID: Email_ID }, { verified: true });
                        await Email_OTP_Verification.deleteMany({ Email_ID });
                        User_data_model.find({ Email_ID: Email_ID })
                            .exec()
                            .then(result => {
                                res.status(200).json({
                                    response: result,
                                    Status_Code: 200
                                });
                            })
                    }
                }
            }
        }
    } catch (error) {
        res.json({
            status: "Failed",
            message: error.message,
            Status_Code: 300
        })
    }
});
 

// router.post('/create_user', async (req, res, next) => {
//     const totalData = await User_data_model.collection.count();
//     bcrypt.hash(req.body.Create_Password, 10, (err, hash) => {
//         if (err) {
//             return res.status(500).json({
//                 error: err
//             })
//         }
//         else {
//             const user_data_model = new User_data_model({
//                 _id: new mongoose.Types.ObjectId,
//                 First_Name: req.body.First_Name,
//                 Last_Name: req.body.Last_Name,
//                 Email_ID: req.body.Email_ID.toLowerCase(),
//                 Referral_By: req.body.Referral_By,
//                 Referral_Code: `ANIB0111${totalData + 1}`,
//                 Account_Type: req.body.Account_Type,
//                 Payment_Amount: req.body.Payment_Amount,
//                 Payment_Status: '',
//                 Payment_Prof: null,
//                 password: hash,
//                 Account_Created_Time: new Date(),
//                 Activate_AI_Boat_Status:'Pending',
//                 Daily_Earning_Amount: 0, 
//             })
//             user_data_model.save()
//                 .then(result => {
//                     res.status(200).json({
//                         message: "Registration Success!!",
//                         status_coe: 200
//                     })
//                 })
//                 .catch(err => {
//                     // console.log(err);
//                     res.status(500).json({
//                         error: err
//                     })
//                 })
//             var mailOptions = {
//                 from: '"Arena FX" <info@arenafx.vip>',
//                 to: user_data_model.Email_ID,
//                 subject: 'Welcome to Arena FX – Thank You for Choosing Us!',
//                 html: `<p>Dear <strong>${user_data_model.First_Name} !</strong></p>
//                 <p>We are delighted to welcome you to Arena FX and thank you for choosing us as your trusted partner in forex trading.</p><br>
//                 <p>At Arena FX, we are committed to providing you with the best trading experience, cutting-edge technology, and exceptional customer service. Whether you are a seasoned trader or just starting, our platform is designed to meet your needs and help you achieve your financial goals.</p><br>
//                 <p>Here’s what you can look forward to as a valued client of Arena FX:</p>
//                 <p><strong>1. Advanced Trading Platform: </strong>Experience seamless trading with our state-of-the-art platform, equipped with powerful tools and real-time data to keep you ahead of the market.</p>
//                 <p><strong>2. Comprehensive Educational Resources: </strong>Access a wealth of educational materials, including webinars, tutorials, and market analysis, to enhance your trading knowledge and skills.</p>
//                 <p><strong>3. Dedicated Customer Support:</strong> Our professional support team is available 24/7 to assist you with any questions or concerns you may have.</p>
//                 <p><strong>4. Competitive Spreads and Leverage: </strong>Benefit from competitive spreads and leverage options tailored to suit different trading strategies.</p>
//                 <p>To get started, simply log in to your account and explore the various features and resources available to you. If you have any questions or need assistance, do not hesitate to contact our support team at [support@arenaFX.com] or call us at [phone number].</p>
//                 <p>Thank you once again for choosing Arena FX. We look forward to supporting your trading journey and achieving success together.</p><br><br>
//                 <p>Best regards,</p>
//                 <p>Customer Support Team</p>
//                 <p>Arena FX</p> 
//                  `
//             }
//             transporter.sendMail(mailOptions, function (error, info) {
//                 if (error) {
//                     // console.log(error)
//                 }
//                 else {
//                     console.log('verification Sent!!!!')
//                 }
//             })
//         }
//     })
// })


router.post('/create_user', async (req, res, next) => {
    try {
        const totalData = await User_data_model.collection.countDocuments();
        const hashedPassword = await bcrypt.hash(req.body.Create_Password, 10);
        const newUser = new User_data_model({
            _id: new mongoose.Types.ObjectId(),
            First_Name: req.body.First_Name,
            Last_Name: req.body.Last_Name,
            Email_ID: req.body.Email_ID.toLowerCase(),
            Referral_By: req.body.Referral_By,
            Referral_Code: `ANIB0111${totalData + 1}`,
            Account_Type: req.body.Account_Type,
            Payment_Amount: req.body.Payment_Amount,
            Payment_Status: '',
            Payment_Prof: null,
            password: hashedPassword,
            Account_Created_Time: new Date(),
            Activate_AI_Boat_Status: 'Pending',
            Daily_Earning_Amount: 0,
            Level_Income: 0
        });

        if (req.body.Referral_By) {
            const First_Level_referrer = await User_data_model.findOne({ Referral_Code: req.body.Referral_By });
            const First_Level_Referral_By = First_Level_referrer?.Referral_By;

            if (First_Level_referrer) {
                // if (First_Level_referrer.Level_One.length < 3) {
                //     First_Level_referrer.Level_One.push(First_Level_referrer.Level_One.length + 1);
                //     First_Level_referrer.Level_One_Referal.push(newUser.Referral_Code);
                // }
                First_Level_referrer.Level_One.push(First_Level_referrer.Level_One.length + 1);
                First_Level_referrer.Level_One_Referal.push(newUser.Referral_Code);
                await First_Level_referrer.save();
            }

            if (First_Level_Referral_By) {
                const Second_Level_referrer = await User_data_model.findOne({ Referral_Code: First_Level_Referral_By });
                const Second_Level_Referral_By = Second_Level_referrer?.Referral_By;

                if (Second_Level_referrer) {
                    // if (Second_Level_referrer.Level_Two.length < 3) {
                    //     Second_Level_referrer.Level_Two.push(Second_Level_referrer.Level_Two.length + 1);
                    //     Second_Level_referrer.Level_Two_Referal.push(newUser.Referral_Code);
                    // }
                    Second_Level_referrer.Level_Two.push(Second_Level_referrer.Level_Two.length + 1);
                    Second_Level_referrer.Level_Two_Referal.push(newUser.Referral_Code);
                    await Second_Level_referrer.save();
                }

                if (Second_Level_Referral_By) {
                    const Third_Level_referrer = await User_data_model.findOne({ Referral_Code: Second_Level_Referral_By });

                    if (Third_Level_referrer) {
                        // if (Third_Level_referrer.Level_Three.length < 3) {
                        //     Third_Level_referrer.Level_Three.push(Third_Level_referrer.Level_Three.length + 1);
                        //     Third_Level_referrer.Level_Three_Referal.push(newUser.Referral_Code);
                        // }
                        Third_Level_referrer.Level_Three.push(Third_Level_referrer.Level_Three.length + 1);
                        Third_Level_referrer.Level_Three_Referal.push(newUser.Referral_Code);
                        await Third_Level_referrer.save();
                    }
                }
            }
        }

        await newUser.save();
        const mailOptions = {
            from: '"Arena FX" <info@arenafx.vip>',
            to: newUser.Email_ID,
            subject: 'Welcome to Arena FX – Thank You for Choosing Us!',
            html: `<p>Dear <strong>${newUser.First_Name}!</strong></p>
                    <p>We are delighted to welcome you to Arena FX and thank you for choosing us as your trusted partner in forex trading.</p><br>
                    <p>At Arena FX, we are committed to providing you with the best trading experience, cutting-edge technology, and exceptional customer service. Whether you are a seasoned trader or just starting, our platform is designed to meet your needs and help you achieve your financial goals.</p><br>
                    <p>Here’s what you can look forward to as a valued client of Arena FX:</p>
                    <p><strong>1. Advanced Trading Platform: </strong>Experience seamless trading with our state-of-the-art platform, equipped with powerful tools and real-time data to keep you ahead of the market.</p>
                    <p><strong>2. Comprehensive Educational Resources: </strong>Access a wealth of educational materials, including webinars, tutorials, and market analysis, to enhance your trading knowledge and skills.</p>
                    <p><strong>3. Dedicated Customer Support:</strong> Our professional support team is available 24/7 to assist you with any questions or concerns you may have.</p>
                    <p><strong>4. Competitive Spreads and Leverage: </strong>Benefit from competitive spreads and leverage options tailored to suit different trading strategies.</p>
                    <p>To get started, simply log in to your account and explore the various features and resources available to you. If you have any questions or need assistance, do not hesitate to contact our support team at [support@arenaFX.com] or call us at [phone number].</p>
                    <p>Thank you once again for choosing Arena FX. We look forward to supporting your trading journey and achieving success together.</p><br><br>
                    <p>Best regards,</p>
                    <p>Customer Support Team</p>
                    <p>Arena FX</p>`
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error(error);
            } else {
                console.log('Verification Sent!');
            }
        });

        res.status(200).json({
            message: "Registration Success!!",
            status_code: 200
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: error
        });
    }
});
 
router.post('/login', (req, res, next) => {
    User_data_model.find({ Email_ID: req.body.Email_ID.toLowerCase() })
        .exec()
        .then(user => {
            if (user.length < 1) {
                return res.status(200).json({
                    message: 'invalid Credentials!',
                    status_code: 404
                })
            }
            bcrypt.compare(req.body.password, user[0].password, (err, result) => {
                if (!result) {
                    return res.status(200).json({
                        message: 'invalid Credentials!',
                        status_code: 404
                    })
                }
                if (result) {
                    const token = jwt.sign({
                        AuthKey: user[0]._id,
                        status_code: 200
                    },
                        'User Details',
                        {
                            expiresIn: "12h"
                        }
                    );
                    res.status(200).json({
                        token: token,
                        status_code: 200
                    })
                }
            })
        })
        .catch(err => {
            res.status(500).json({
                err: err
            })
        })
})

router.post('/ForgotPassword', (req, res, next) => {
    User_data_model.find({ Email_ID: req.body.Email_ID.toLowerCase() })
        .select("-__v")
        .exec()
        .then(result => {
            if (result.length !== 0) {
                Email_OTP_Verification.find({ Email_ID: req.body.Email_ID.toLowerCase() })
                    .exec()
                    .then(result => {
                        if (result.length !== 0) {
                            Email_OTP_Verification.remove({ Email_ID: req.body.Email_ID.toLowerCase() })
                                .then(result => {
                                    const Email_ID = req.body.Email_ID.toLowerCase();
                                    const Name = req.body.First_Name;
                                    SendOTPVerificationEmail(Email_ID, Name)
                                    res.status(200).json({
                                        message: "OTP has been sent successfully!!",
                                        Status_Code: 200
                                    });
                                })
                        }
                        if (result.length == 0) {
                            const Email_ID = req.body.Email_ID.toLowerCase();
                            const Name = req.body.First_Name;
                            ForgotPassword(Email_ID, Name)
                            res.status(200).json({
                                message: "OTP has been sent successfully!!",
                                Status_Code: 200
                            });
                        }
                    })
            }
            if (result.length == 0) {
                res.status(200).json({
                    message: "Please enter valid email ID",
                    Status_Code: 300
                });
            }
        })
        .catch(err => {
            res.status(500).json({
                error: err
            })
        })
})

const ForgotPassword = async (Email_ID, Name, res) => {
    try {
        const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
        const mailOptions = {
            from: '"Arena FX" <info@arenafx.vip>',
            to: Email_ID,
            subject: 'Email OTP verificartion',
            html: `
            <p>Dear <strong>${Name} !</strong> </p> 
            <p>For your security, we have generated a One-Time Password (OTP) to complete your recent action on Arena FX. Please use the OTP below to proceed:</p>
            <p>Your OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
            <p>This OTP is valid for the next 2 minutes. If you did not request this OTP, please contact our support team immediately.</p><br>
            <p>To ensure the security of your account, do not share this OTP with anyone. Arena FX will never ask you for your password or OTP.</p>
            <p>If you have any questions or need further assistance, feel free to contact us at support@arenaFX.com.</p><br>
            <p>Thank you for choosing Arena FX.</p><br>
            <p>Best regards,</p>
            <p>Customer Support Team </p>
            <p>Arena FX VIP</p> 
            `
        };
        const saltRounds = 2;
        const hashedOTP = await bcrypt.hash(otp, saltRounds);
        const email_OTP_Verification = await Email_OTP_Verification({
            _id: new mongoose.Types.ObjectId,
            Email_ID: Email_ID,
            otp: hashedOTP,
            CreatedTime: Date.now(),
            ExpiredTime: Date.now() + 120000,
        });
        await email_OTP_Verification.save();
        await transporter.sendMail(mailOptions);
    }
    catch (error) {
        res.json({
            status: "Failed",
            message: error.message,
        });
    }
}

router.put('/ForgotPassword/:_id', (req, res, next) => {
    bcrypt.hash(req.body.password, 10, (err, hash) => {
        if (err) {
            return res.status(500).json({
                error: err
            })
        }
        else {
            User_data_model.findOneAndUpdate({ _id: req.params._id }, {
                $set: {
                    password: hash,
                }
            })
                .then(result => {
                    res.status(200).json({
                        message: 'Password created!!',
                        Status_Code: 200
                    })
                    var mailOptions = {
                        from: '"Arena FX" <info@arenafx.vip>',
                        to: result.Email_ID,
                        subject: 'Password Created Successfully done ',
                        html: `<p>Dear <strong>${result.First_Name} !</strong></p> 
                        <p></p>
                        `
                    }
                    transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                        }
                        else {
                            console.log('verification Sent!!!!')
                        }
                    })
                })
                .catch(err => {
                    res.status(500).json({
                        error: err
                    })
                })
        }
    })
})

module.exports = router; 
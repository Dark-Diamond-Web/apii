const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const User_data_model = require('../Model/user_data_model');
const PaymentRequest = require('../Model/payment_request');
const httpContext = require('express-http-context');
const wallet_model = require('../Model/user_wallet_data');
const DailyEarningInfo = require('../Model/Daily_EarningInfo');
const moment = require('moment');

router.get('/UserList', (req, res, next) => {
    User_data_model.find({})
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                ClientList: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.get('/UserList', (req, res, next) => {
    User_data_model.find({})
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                ClientList: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.get('/ActiveUser', (req, res, next) => {
    User_data_model.find({ Payment_Status: 'Approved' })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                ActiveUser: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.get('/PendingApproval', (req, res, next) => {
    User_data_model.find({ Payment_Status: 'Pending' })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                PendingApproval: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})
router.get('/VIP_Client', (req, res, next) => {
    User_data_model.find({ Account_Type: 'Pro', Payment_Status: 'Approved' })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                ProUser: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})
router.get('/Lite_Client', (req, res, next) => {
    User_data_model.find({ Account_Type: 'Lite', Payment_Status: 'Approved' })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const formattedAccountCreatedTime = moment(item.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                };
            });
            res.status(200).json({
                LiteUser: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.put('/Approved/:_id', (req, res, next) => {
    User_data_model.findOneAndUpdate({ _id: req.params._id }, {
        $set: {
            Payment_Status: req.body.Payment_Status,
        }
    })
        .then(result => {
            // console.log(result)
            res.status(200).json({
                Updated: result,
                Status_Code: 200
            })
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.get('/Payment_Withdraw_Request', (req, res, next) => {
    PaymentRequest.find({ Payment_Status: 'Pending' })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const RequestTime = moment(item.RequestTime).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    RequestTime: RequestTime
                };
            });
            res.status(200).json({
                Request: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.post('/WalletDetails', (req, res, next) => {
    wallet_model.find({ _id: req.body.id })
        .select("-__v")
        .exec()
        .then(result => {
            res.status(200).json({
                wallet_Data: result,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.put('/PaymentRequest/:_id', (req, res, next) => {
    PaymentRequest.findOneAndUpdate({ _id: req.params._id }, {
        $set: {
            Payment_Status: req.body.Payment_Status,
        }
    })
        .then(result => {
            // console.log(result)
            res.status(200).json({
                Updated: result,
                Status_Code: 200
            })
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.post('/update_daily_earning', (req, res, next) => {
    const SelectedPercentage = req.body.Entred_Percentage;
    // console.log(SelectedPercentage)
    User_data_model.find({Activate_AI_Boat_Status: 'Activated'})
    .select("-__v, -Payment_Prof")
    .exec()
    .then(async result => {
        // console.log(result);
        for (let i = 0; i < result.length; i++) {
            const user = result[i];
            // console.log(user);
            const updatedAmount = user.Payment_Amount * SelectedPercentage;
            user.Daily_Earning_Amount = user.Daily_Earning_Amount + updatedAmount;
            user.LatestUpdateDailyEarning = new Date();
            await user.save(); 
        }
        const dailyEarningInfo = new DailyEarningInfo({
            _id: new mongoose.Types.ObjectId,
            SelectedPercentage: SelectedPercentage,
            LatestUpdateDailyEarning: new Date(),
        })
        dailyEarningInfo.save()
        res.status(200).json({
            Updated: result,
            Status_Code: 200
        })
    })
    .catch(err => {
        // console.log(err);
        res.status(500).json({
            error: err
        })
    })
}) 

router.get('/Latest_Update', (req, res, next) => {
    DailyEarningInfo.find({})
        .sort({ LatestUpdateDailyEarning: -1 })
        .limit(1) 
        .select("-__v")
        .exec()
        .then(result => {
            if (result.length === 0) { 
                return res.status(404).json({
                    message: "No data found"
                });
            } 
            const formattedTime = moment(result[0].LatestUpdateDailyEarning).format('YYYY-MM-DD HH:mm:ss'); 
            const updatedResult = {
                ...result[0]._doc,
                LatestUpdateDailyEarning: formattedTime
            };
            res.status(200).json({
                Update: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

// User_data_model.find({Activate_AI_Boat_Status: 'Activated'})
//     .select("-__v, -Payment_Prof")
//     .exec()
//     .then(async result => {
//         // console.log(result)
//         for (let i = 0; i < result.length; i++) {
//             const user = result[i];
//             console.log(user)
//             const updatedAmount = user.Payment_Amount * 0.005;
//             user.Daily_Earning_Amount = user.Daily_Earning_Amount + updatedAmount;
//             await user.save(); 
//         }
//     })











 

module.exports = router; 
const mongoose = require('mongoose');
const Admin = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    AuthKey: String,
    First_Name: String,
    Last_Name: String,
    Email_ID: String, 
    password: String,
    Account_Created_Time: Date,
})
module.exports = mongoose.model('Admin', Admin)

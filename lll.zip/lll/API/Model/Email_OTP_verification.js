const mongoose = require('mongoose');
const Email_OTP_Verification = new mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,  
    Email_ID:String,
    otp:String,  
    CreatedTime:Date,  
    ExpiredTime:Date
})
module.exports = mongoose.model("Email_OTP_Verification",Email_OTP_Verification)

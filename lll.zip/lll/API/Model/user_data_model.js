const mongoose = require('mongoose');
const user_data = new mongoose.Schema({   
    _id: mongoose.Schema.Types.ObjectId,
    AuthKey: String,
    First_Name: String,
    Last_Name: String,
    Email_ID: String,
    Referral_Code: String,
    Referral_By: String,
    Account_Type: String,
    Payment_Status: String,
    Payment_Amount: Number,
    Payment_Prof: String,
    password: String,
    Account_Created_Time: Date,
    Daily_Earning_Amount: Number,
    Activate_AI_Boat_Status: String,
    Activate_AI_Boat_Date: Date,
    Daily_Earning_Date: String,
    Payment_Approve_Date: Date,
    LatestUpdateDailyEarning: Date,

    Level_Income: Number,
    Level_Activate_Date: Date,
 


    Level_One: [Number],
    Level_One_Referal: [String],
    Level_Two: [Number],
    Level_Two_Referal: [String],
    Level_Three: [Number],
    Level_Three_Referal: [String],
})
module.exports = mongoose.model('user_data', user_data)
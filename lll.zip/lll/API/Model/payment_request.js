const mongoose = require('mongoose');
const UserPayment = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    AuthKey: String,
    First_Name: String,
    Last_Name: String,
    Email_ID: String,
    wallet_Amount: String,
    wallet_Account: String,
    Payment_Status: String,
    PaymentType: String,
    RequestTime: Date,
})
module.exports = mongoose.model('UserPaymentRequest', UserPayment) 

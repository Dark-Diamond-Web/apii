const mongoose = require('mongoose');
const UserWalletData = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    AuthKey: String,
    wallet_name: String,
    Wallet_Address: String,
    QR_ScrShot: String,
})
module.exports = mongoose.model('UserWalletData', UserWalletData) 